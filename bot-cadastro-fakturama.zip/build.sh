#!/bin/bash

zip -r "bot-cadastro-fakturama.zip" * -x "bot-cadastro-fakturama.zip"