$exclude = @("venv", "bot-cadastro-fakturama.zip")
$files = Get-ChildItem -Path . -Exclude $exclude
Compress-Archive -Path $files -DestinationPath "bot-cadastro-fakturama.zip" -Force