"""
WARNING:

Please make sure you install the bot dependencies with `pip install --upgrade -r requirements.txt`
in order to get all the dependencies on your Python environment.

Also, if you are using PyCharm or another IDE, make sure that you use the SAME Python interpreter
as your IDE.

If you get an error like:
```
ModuleNotFoundError: No module named 'botcity'
```

This means that you are likely using a different Python interpreter than the one used to install the dependencies.
To fix this, you can either:
- Use the same interpreter as your IDE and install your bot with `pip install --upgrade -r requirements.txt`
- Use the same interpreter as the one used to install the bot (`pip install --upgrade -r requirements.txt`)

Please refer to the documentation for more information at
https://documentation.botcity.dev/tutorials/python-automations/desktop/
"""

#Import for the Desktop Bot
from botcity.core import DesktopBot

#Import for integration with BotCity Maestro SDK
from botcity.maestro import *

#Disable errors if we are not connected to Maestro
BotMaestroSDK.RAISE_NOT_CONNECTED = False

def main():
    #Initialize the Maestro SDK and fetch the task execution details
    maestro = BotMaestroSDK.from_sys_args()
    execution = maestro.get_execution()

    print(f"Task ID is: {execution.task_id}")
    print(f"Task Parameters are: {execution.parameters}")   

    #Read product data from CSV
    from botcity.plugins.csv import BotCSVPlugin
    planilha = BotCSVPlugin()
    dados = planilha.read(rf"resources\produtos\items.csv").as_list()
    print(dados)

    bot = DesktopBot()

    # Uncomment if the Fakturama needs to be launched
    #bot.execute(r"C:\Program Files\Fakturama2\Fakturama.exe")
    # bot.wait(5000)  # Wait for the application to load

    #Iterate over the product data and fill in the fields (separate function to encapsulate the form filling logic. )
    for item in dados:
        if not fill_product_form(bot, item):
            print(f"Failed to process product: {item[2]}")

    # Close the application
    bot.alt_f4()

    # Uncomment to mark this task as finished on BotMaestro
    maestro.finish_task(
        task_id=execution.task_id,
        status=AutomationTaskFinishStatus.SUCCESS,
        message="Bot Fakturama OK."
    )

def fill_product_form(bot, item):
    #Function to fill the product form
    if not bot.find("new_product", matching=0.95, waiting_time=30000):
        return not_found("new_product")
    bot.click()
    bot.wait(200)

    if not bot.find("item_number", matching=0.95, waiting_time=15000):
        return not_found("item_number")
    bot.click_relative(147, 7)
    bot.wait(200)

    #Fields to fill in (list to store the values to be filled in)
    fields = [
        (item[1], "item_number"),  # Item number
        (item[2], "name"),          # Product name
        (item[3], "category"),      # Category
        (item[4], "gtin"),          # GTIN
        (item[5], "supcode"),       # Supplier code
        (item[6], "description"),   # Description
        (str(item[7]), "price"),    # Selling price
        (str(item[8]), "costprice"),# Cost price
        (str(item[9]), "allowance"),# Allowance
        (str(item[14]), "quantity") # Quantity
    ]

    for value, field in fields:
        bot.control_a()
        bot.paste(value)
        bot.wait(200)
        bot.tab()

    #Image name input (images in the resources repository )
    if not bot.find("select", matching=0.95, waiting_time=15000):
        return not_found("select")
    bot.click()
    bot.wait(200)
    bot.paste(rf"C:\Users\Letícia Goulart\Documents\RPA\BotCity\Fakturama\bot-cadastro-fakturama\resources\imagens_produtos\{item[13]}")
    bot.enter()
    bot.wait(200)

    #Save the product
    if not bot.find("save", matching=0.95, waiting_time=15000):
        return not_found("save")
    bot.click()
    bot.wait(200)

    #Close the product form
    bot.control_w()
    bot.wait(200)

    return True

def not_found(label):
    print(f"Element not found: {label}")
    return False

if __name__ == '__main__':
    main()
